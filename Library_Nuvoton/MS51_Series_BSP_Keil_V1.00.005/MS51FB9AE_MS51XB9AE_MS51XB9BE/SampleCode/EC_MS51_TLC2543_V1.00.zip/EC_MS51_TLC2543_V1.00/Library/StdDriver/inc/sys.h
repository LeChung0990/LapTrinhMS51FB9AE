void MODIFY_HIRC_166(void);
void MODIFY_HIRC_16(void);
void MODIFY_HIRC_24(void);