/**************************************************************************//**
 * @file     main.c
 * @brief
 *           TLC2543 driver
 *
 * @note
 * Copyright (C) 2019 Nuvoton Technology Corp. All rights reserved.
 *****************************************************************************/

#include "MS51_16K.H"


extern void TLC2543_Init(void);
extern uint16_t TLC2543_Read(uint8_t u8Channel);


/*---------------------------------------------------------------------------*/
/* MAIN function                                                             */
/*---------------------------------------------------------------------------*/
void main (void)
{
    uint16_t u16Data = 0;

    /* Modify HIRC to 24MHz is for UART baud rate deviation not over 1% */
    MODIFY_HIRC_24();
    UART_Open(24000000, UART0_Timer3, 115200);
    ENABLE_UART0_PRINTF;                              // Important! use prinft function must set TI=1;

    printf("+-------------------------------------------------------+\n");
    printf("|   TLC2543 Driver                                      |\n");
    printf("+-------------------------------------------------------+\n");

    TLC2543_Init();

    while(1)
    {
        u16Data = TLC2543_Read(0);

        printf("The ADC data is: 0x%x \n", u16Data);

        Timer0_Delay(24000000, 300, 1000);
    }
}

/*** (C) COPYRIGHT 2019 Nuvoton Technology Corp. ***/