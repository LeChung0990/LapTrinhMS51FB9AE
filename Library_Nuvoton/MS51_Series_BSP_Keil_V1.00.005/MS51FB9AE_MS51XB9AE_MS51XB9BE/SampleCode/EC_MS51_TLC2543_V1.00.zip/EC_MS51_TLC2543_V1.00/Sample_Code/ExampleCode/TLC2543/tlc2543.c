/**************************************************************************//**
 * @file     tlc2543.c
 * @brief
 *           TLC2543 driver source file
 *
 * @note
 * Copyright (C) 2019 Nuvoton Technology Corp. All rights reserved.
 *****************************************************************************/

#include "MS51_16K.H"


/*---------------------------------------------------------------------------*/
/* Define                                                                    */
/*---------------------------------------------------------------------------*/
#define TLC2543_CS      P10 //TLC2543 chip select pin.
#define TLC2543_DOUT    P11 //TLC2543 data out pin.
#define TLC2543_DIN     P13 //TLC2543 data in pin.
#define TLC2543_CLK     P14 //TLC2543 clock pin.
#define TLC2543_EOC     P15 //TLC2543 end of conversion pin.


/*---------------------------------------------------------------------------*/
/* Functions                                                                 */
/*---------------------------------------------------------------------------*/
void TLC2543_Delay(void)
{
    _nop_();
    _nop_();
    _nop_();
    _nop_();
    _nop_();
}


void TLC2543_Init(void)
{
    P10_PUSHPULL_MODE; //TLC2543 chip select pin.
    P11_INPUT_MODE;    //TLC2543 data out pin.
    P13_PUSHPULL_MODE; //TLC2543 data in pin.
    P14_PUSHPULL_MODE; //TLC2543 clock pin.
    P15_INPUT_MODE;    //TLC2543 end of conversion pin.

    TLC2543_CS = 1;
    TLC2543_DIN = 1;
    TLC2543_CLK = 0;
}


/**
  * @brief Read the conversion data of TLC2543.
  *
  * @param[in] u8Channel define the conversion channel, from 0~11.
  *
  * @return  The conversion data. It is the previous conversion data.
*/
uint16_t TLC2543_Read(uint8_t u8Channel)
{
    uint16_t u16DataOut = 0;
    uint16_t u16DataIn = 0;
    uint8_t i = 0;

    u16DataOut = ((uint16_t)u8Channel) << 12;

    TLC2543_CS = 0;

    for(i = 0; i < 12; i++)
    {
        TLC2543_CLK = 0;
        TLC2543_DIN = (bit)(u16DataOut & 0x8000);
        u16DataOut <<= 1;
        TLC2543_Delay();
        TLC2543_CLK = 1;
        u16DataIn <<= 1;
        if(TLC2543_DOUT == 1)
        {
            u16DataIn |= 0x01;
        }
        TLC2543_Delay();
    }

    TLC2543_CLK = 0;
    TLC2543_Delay();
    TLC2543_CS = 1;
    TLC2543_Delay();

    while(TLC2543_EOC == 0);

    return u16DataIn;
}

/*** (C) COPYRIGHT 2019 Nuvoton Technology Corp. ***/